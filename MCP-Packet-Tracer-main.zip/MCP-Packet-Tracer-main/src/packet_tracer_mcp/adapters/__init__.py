"""Adapters layer."""
