# 🌐 Red Empresarial — 15 Routers, OSPF, VLSM y Router on a Stick

> Guía completa y **100% gratuita** para construir una topología de red empresarial en **Cisco Packet Tracer** con 16 subredes, 15 switches, Router on a Stick con VLANs, DHCP automático y enrutamiento dinámico OSPF usando VLSM sobre el espacio `192.168.168.0/20`.

![Cisco Packet Tracer](https://img.shields.io/badge/Cisco-Packet%20Tracer-1BA0D7?style=for-the-badge&logo=cisco&logoColor=white)
![OSPF](https://img.shields.io/badge/Routing-OSPF-green?style=for-the-badge)
![VLSM](https://img.shields.io/badge/Addressing-VLSM-orange?style=for-the-badge)
![Gratuito](https://img.shields.io/badge/Costo-Gratuito-brightgreen?style=for-the-badge)

---

## 📋 Contenido del repositorio

```
📦 red-ospf-vlsm-packet-tracer/
├── 📄 README.md                    ← Esta guía principal
├── 📁 configs/                     ← Configuraciones CLI de cada dispositivo
│   ├── R01_router_on_stick.txt
│   ├── R02_config.txt
│   ├── R03_config.txt
│   ├── ...
│   ├── R15_config.txt
│   └── SW01_vlans_trunk.txt
├── 📁 docs/
│   ├── VLSM_tabla.md               ← Tabla completa de subredes
│   ├── INSTALACION.md              ← Cómo instalar Packet Tracer gratis
│   └── VERIFICACION.md             ← Comandos para verificar la red
└── 📁 scripts/
    └── ptbuilder_script.js         ← Script para construir la topología automáticamente
```

---

## 🏗️ Resumen de la topología

| Elemento | Detalle |
|----------|---------|
| **Routers** | 15 × Cisco 2911 |
| **Switches** | 15 × Cisco 2960-24TT |
| **PCs** | 45 (3 por LAN) |
| **Total de redes** | 16 subredes |
| **Router on a Stick** | R1 con VLAN 10 y VLAN 20 |
| **Protocolo de enrutamiento** | OSPF Proceso 1, Área 0 |
| **Espacio de IPs** | 192.168.168.0/20 |
| **DHCP** | Activado en todos los routers |

### Diagrama de topología

```
                    ┌─────────────────────────────────────────────────┐
                    │           BACKBONE (cadena lineal)               │
                    │                                                  │
[SW1]─[R1]──────[R2]──────[R3]──────[R4]──────[R5]──────[R6]──────[R7]
 │  (RoaS)       │          │          │          │          │          │
VLAN10          [SW2]      [SW3]      [SW4]      [SW5]      [SW6]      [SW7]
VLAN20        PC4-PC6    PC7-PC9  PC10-PC12  PC13-PC15  PC16-PC18  PC19-PC21
PC1-PC3
                    │                                                  │
              [R8]──────[R9]──────[R10]─────[R11]─────[R12]─────[R13]─────[R14]─────[R15]
               │          │          │          │          │          │         │         │
             [SW8]      [SW9]     [SW10]     [SW11]     [SW12]    [SW13]    [SW14]    [SW15]
           PC22-24    PC25-27    PC28-30    PC31-33    PC34-36   PC37-39   PC40-42   PC43-45
```

---

## 🚀 Inicio rápido

1. **Instalar Packet Tracer gratis** → Ver [docs/INSTALACION.md](docs/INSTALACION.md)
2. **Abrir Packet Tracer** y crear nuevo proyecto
3. **Usar el script automático** → Ver [scripts/ptbuilder_script.js](scripts/ptbuilder_script.js)
4. **Pegar las configs CLI** → Ver carpeta [configs/](configs/)
5. **Verificar** → Ver [docs/VERIFICACION.md](docs/VERIFICACION.md)

---

## 📐 Tabla VLSM (resumen)

| # | Subred | Prefijo | Hosts útiles | Uso |
|---|--------|---------|-------------|-----|
| 1 | 192.168.168.0 | /24 | 254 | R1 — VLAN 10 (RoaS) |
| 2 | 192.168.169.0 | /24 | 254 | R1 — VLAN 20 (RoaS) |
| 3–8 | 192.168.170.0 – 175.0 | /24 | 254 c/u | LANs R2–R7 |
| 9–10 | 192.168.168.128 / 169.128 | /25 | 126 c/u | LANs R8–R9 |
| 11–12 | 192.168.170.0 / .64 | /26 | 62 c/u | LANs R10–R11 |
| 13–14 | 192.168.170.128 / .160 | /27 | 30 c/u | LANs R12–R13 |
| 15–16 | 192.168.170.192 / .196 | /30 | 2 c/u | Enlaces WAN R13-R14-R15 |

> Tabla completa con rangos y broadcasts → [docs/VLSM_tabla.md](docs/VLSM_tabla.md)

---

## 📚 Conceptos clave

### OSPF (Open Shortest Path First)
Protocolo de enrutamiento dinámico de **estado de enlace**. Permite que los routers descubran automáticamente todas las rutas de la red sin configuración manual de cada destino.

### VLSM (Variable Length Subnet Masking)
Técnica que divide un bloque de IPs en subredes de **distintos tamaños** según las necesidades reales. Evita desperdiciar IPs: un enlace punto a punto usa `/30` (2 hosts) en vez de una `/24` (254 hosts).

### Router on a Stick
Permite que **un solo router** enrute tráfico entre múltiples VLANs usando **una interfaz física** dividida en subinterfaces virtuales con encapsulación **802.1Q (dot1Q)**.

---

## 🤝 Contribuciones

¿Encontraste un error? ¿Tienes una mejora? ¡Abre un [Issue](../../issues) o envía un [Pull Request](../../pulls)!

---

## 📄 Licencia

Este proyecto es de libre uso educativo. Puedes copiarlo, modificarlo y distribuirlo libremente.

---

*Creado con ❤️ para la comunidad de networking hispana*
