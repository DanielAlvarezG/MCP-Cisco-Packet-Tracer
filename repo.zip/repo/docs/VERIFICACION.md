# ✅ Verificación de la Red

Comandos para verificar que la topología funciona correctamente después de configurarla.

---

## 1. Verificar OSPF

### Ver vecinos OSPF (en cualquier router)
```cisco
show ip ospf neighbor
```
**Resultado esperado:** R2–R14 deben mostrar **2 vecinos**. R1 y R15 deben mostrar **1 vecino**.

```
Neighbor ID     Pri   State           Dead Time   Address         Interface
2.2.2.2           1   FULL/DR         00:00:38    10.0.0.2        GigabitEthernet0/0
```

### Ver tabla de rutas OSPF
```cisco
show ip route ospf
```
**Resultado esperado:** Rutas con código `O` aprendidas dinámicamente hacia todas las redes remotas.

```
O    192.168.1.0 [110/2] via 10.0.0.2, 00:05:12, GigabitEthernet0/0
O    192.168.2.0 [110/3] via 10.0.0.2, 00:05:12, GigabitEthernet0/0
...
```

### Ver base de datos OSPF
```cisco
show ip ospf database
```

### Ver detalles del proceso OSPF
```cisco
show ip ospf
show ip ospf interface brief
```

---

## 2. Verificar conectividad con ping

### Desde un PC — ping al extremo opuesto
Abre cualquier PC → Desktop → Command Prompt:

```
ping 192.168.14.4
```
**Resultado esperado:** 4 respuestas exitosas

```
Pinging 192.168.14.4 with 32 bytes of data:
Reply from 192.168.14.4: bytes=32 time=1ms TTL=111
Reply from 192.168.14.4: bytes=32 time=1ms TTL=111
Reply from 192.168.14.4: bytes=32 time=1ms TTL=111
Reply from 192.168.14.4: bytes=32 time=1ms TTL=111
```

### Ping entre VLANs (Router on a Stick)
Desde un PC en VLAN 10 (192.168.168.x) hacer ping a un PC en VLAN 20 (192.168.169.x):

```
ping 192.168.169.2
```

---

## 3. Verificar Router on a Stick (R1)

### Ver subinterfaces activas
```cisco
show ip interface brief
```
**Resultado esperado:**
```
GigabitEthernet0/1        unassigned      YES unset  up                    up
GigabitEthernet0/1.10     192.168.168.1   YES manual up                    up
GigabitEthernet0/1.20     192.168.169.1   YES manual up                    up
```

### Ver encapsulación dot1Q
```cisco
show interfaces GigabitEthernet0/1.10
show interfaces GigabitEthernet0/1.20
```

---

## 4. Verificar VLANs en SW1

### Ver VLANs configuradas
```cisco
show vlan brief
```
**Resultado esperado:**
```
VLAN Name                             Status    Ports
---- -------------------------------- --------- ----------------------------
1    default                          active    ...
10   DEPARTAMENTO_A                   active    Fa0/1, Fa0/2
20   DEPARTAMENTO_B                   active    Fa0/3
```

### Ver puertos trunk
```cisco
show interfaces trunk
```
**Resultado esperado:** El puerto hacia R1 debe aparecer en modo trunk con VLANs 10 y 20.

---

## 5. Verificar DHCP

### Ver asignaciones DHCP (en cada router)
```cisco
show ip dhcp binding
```
**Resultado esperado:** Lista de IPs asignadas a cada PC.

```
IP address       Client-ID/              Lease expiration        Type
                 Hardware address
192.168.0.2      0060.2FA0.0001          --                      Automatic
192.168.0.3      0060.2FA0.0002          --                      Automatic
```

### Ver estadísticas del pool
```cisco
show ip dhcp pool
```

### Renovar IP en un PC (si no obtiene IP automáticamente)
En el PC → Desktop → Command Prompt:
```
ipconfig /release
ipconfig /renew
ipconfig /all
```

---

## 6. Verificar conectividad física

### Ver estado de todas las interfaces de un router
```cisco
show ip interface brief
```
Todas las interfaces conectadas deben estar **up/up**.

### Ver detalles de una interfaz específica
```cisco
show interfaces GigabitEthernet0/0
```

---

## 7. Tabla de verificación completa

Usa esta checklist para confirmar que todo funciona:

| # | Verificación | Comando | ✅ Esperado |
|---|-------------|---------|------------|
| 1 | OSPF activo en R1 | `show ip ospf neighbor` | 1 vecino (R2) |
| 2 | OSPF activo en R8 | `show ip ospf neighbor` | 2 vecinos |
| 3 | Rutas OSPF en R1 | `show ip route ospf` | 14+ rutas `O` |
| 4 | Ping PC1 → PC45 | `ping 192.168.14.4` | 4/4 replies |
| 5 | Ping entre VLANs | `ping 192.168.169.2` | 4/4 replies |
| 6 | Subinterfaces R1 | `show ip int brief` | Gi0/1.10 y .20 up |
| 7 | VLANs en SW1 | `show vlan brief` | VLAN 10 y 20 activas |
| 8 | Trunk SW1→R1 | `show interfaces trunk` | Puerto en trunk |
| 9 | DHCP asignando | `show ip dhcp binding` | 3 IPs por router |
| 10 | Todas interfaces up | `show ip int brief` | No hay down/down |

---

## 8. Comandos de depuración (si algo no funciona)

```cisco
! Depurar OSPF en tiempo real
debug ip ospf events
debug ip ospf adj
no debug all   ! para detener el debug

! Depurar DHCP
debug ip dhcp server events
no debug all

! Ver configuración completa
show running-config
show running-config | section ospf
show running-config | section interface
```

---

*← [Volver al README principal](../README.md)*
