# 🆓 Instalación gratuita de Cisco Packet Tracer

Cisco Packet Tracer es **100% gratuito** para uso personal y educativo. Sigue estos pasos según tu sistema operativo.

---

## Paso 1 — Crear cuenta en Cisco NetAcad

1. Abre tu navegador y ve a: **https://www.netacad.com**
2. Haz clic en **"Sign up"** (esquina superior derecha)
3. Rellena el formulario:
   - Nombre y apellido
   - Correo electrónico válido
   - Contraseña
   - País
4. Acepta los términos y condiciones
5. Verifica tu correo: recibirás un enlace de activación

> 💡 Si ya tienes cuenta, salta directamente al Paso 2.

---

## Paso 2 — Inscribirse al curso gratuito

Necesitas inscribirte a un curso para desbloquear la descarga:

1. Inicia sesión en **https://www.netacad.com**
2. En el menú superior, haz clic en **"Courses"** → **"Catalog"**
3. Busca **"Networking Essentials"** o **"Introduction to Packet Tracer"**
4. Haz clic en el curso → **"Get Started"** o **"Enroll"**
5. Es completamente **gratuito**, sin tarjeta de crédito

---

## Paso 3 — Descargar Packet Tracer

### Opción A — Desde el portal NetAcad

1. Ingresa a: **https://www.netacad.com/resources/lab-downloads**
2. Busca la sección **"Packet Tracer"**
3. Selecciona tu sistema operativo

### Opción B — Desde Skills for All (más fácil)

1. Ve a: **https://skillsforall.com/resources/lab-downloads**
2. Selecciona **Packet Tracer** para tu sistema operativo
3. No requiere inscripción a ningún curso

---

## Paso 4 — Instalación por sistema operativo

### 🪟 Windows

1. Descarga el archivo `.exe` (aprox. 160 MB)
2. Ejecuta el instalador como administrador
3. Sigue el asistente con las opciones predeterminadas
4. Al finalizar, **NO** marques "Launch Packet Tracer" aún

### 🍎 macOS

1. Descarga el archivo `.dmg`
2. Abre el `.dmg` y arrastra Packet Tracer a **Aplicaciones**
3. En la primera apertura: clic derecho → **"Abrir"** → confirmar

### 🐧 Linux (Ubuntu/Debian)

```bash
# Descarga el archivo .deb
chmod +x PacketTracer_*.deb
sudo dpkg -i PacketTracer_*.deb
sudo apt-get install -f  # instalar dependencias faltantes
```

---

## Paso 5 — Primer inicio de sesión

1. Abre **Cisco Packet Tracer**
2. Aparecerá una ventana de inicio de sesión
3. Ingresa con tu cuenta **NetAcad**
4. ¡Listo! Ya puedes usar todas las funciones

> 💡 **Modo sin cuenta:** Si no quieres registrarte, haz clic en **"Guest Login"**. Tendrás funcionalidad básica pero no podrás guardar en la nube.

---

## Versiones recomendadas

| Versión | Estado | Recomendada para |
|---------|--------|-----------------|
| 8.2.x | Estable | ✅ Esta guía |
| 8.1.x | Estable | ✅ Compatible |
| 7.x | Antigua | ⚠️ Puede faltar funciones |

---

## Recursos adicionales

- 📖 Documentación oficial: https://www.netacad.com/courses/packet-tracer
- 🎓 Curso gratuito de redes: https://skillsforall.com
- 💬 Foro de Cisco: https://learningnetwork.cisco.com

---

*← [Volver al README principal](../README.md)*
