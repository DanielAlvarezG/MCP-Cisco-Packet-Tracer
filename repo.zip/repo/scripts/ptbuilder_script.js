// ============================================================
// SCRIPT PTBUILDER — Red 15 Routers + OSPF + VLSM + RoaS
// 
// INSTRUCCIONES DE USO:
// 1. Abre Cisco Packet Tracer
// 2. Ve al menu: Extensions → PacketTracer Builder
//    (o presiona Ctrl+Shift+X)
// 3. En "Builder Code Editor", pega TODO este script
// 4. Haz clic en "Run" o presiona Ctrl+Enter
// 5. Espera ~30 segundos a que se construya la topología
// 
// Después de correr el script, ve a la carpeta configs/
// y aplica las configuraciones CLI en cada dispositivo.
// ============================================================

// --- ROUTERS ---
addDevice("R1",  "2911", 100,  100);
addDevice("R2",  "2911", 350,  100);
addDevice("R3",  "2911", 600,  100);
addDevice("R4",  "2911", 850,  100);
addDevice("R5",  "2911", 1100, 100);
addDevice("R6",  "2911", 1350, 100);
addDevice("R7",  "2911", 1600, 100);
addDevice("R8",  "2911", 1850, 100);
addDevice("R9",  "2911", 2100, 100);
addDevice("R10", "2911", 2350, 100);
addDevice("R11", "2911", 2600, 100);
addDevice("R12", "2911", 2850, 100);
addDevice("R13", "2911", 3100, 100);
addDevice("R14", "2911", 3350, 100);
addDevice("R15", "2911", 3600, 100);

// --- SWITCHES ---
addDevice("SW1",  "2960-24TT", 100,  250);
addDevice("SW2",  "2960-24TT", 350,  250);
addDevice("SW3",  "2960-24TT", 600,  250);
addDevice("SW4",  "2960-24TT", 850,  250);
addDevice("SW5",  "2960-24TT", 1100, 250);
addDevice("SW6",  "2960-24TT", 1350, 250);
addDevice("SW7",  "2960-24TT", 1600, 250);
addDevice("SW8",  "2960-24TT", 1850, 250);
addDevice("SW9",  "2960-24TT", 2100, 250);
addDevice("SW10", "2960-24TT", 2350, 250);
addDevice("SW11", "2960-24TT", 2600, 250);
addDevice("SW12", "2960-24TT", 2850, 250);
addDevice("SW13", "2960-24TT", 3100, 250);
addDevice("SW14", "2960-24TT", 3350, 250);
addDevice("SW15", "2960-24TT", 3600, 250);

// --- PCS (3 por switch) ---
addDevice("PC1",  "PC-PT", -20,  400); addDevice("PC2",  "PC-PT", 60,   400); addDevice("PC3",  "PC-PT", 140,  400);
addDevice("PC4",  "PC-PT", 230,  400); addDevice("PC5",  "PC-PT", 310,  400); addDevice("PC6",  "PC-PT", 390,  400);
addDevice("PC7",  "PC-PT", 480,  400); addDevice("PC8",  "PC-PT", 560,  400); addDevice("PC9",  "PC-PT", 640,  400);
addDevice("PC10", "PC-PT", 730,  400); addDevice("PC11", "PC-PT", 810,  400); addDevice("PC12", "PC-PT", 890,  400);
addDevice("PC13", "PC-PT", 980,  400); addDevice("PC14", "PC-PT", 1060, 400); addDevice("PC15", "PC-PT", 1140, 400);
addDevice("PC16", "PC-PT", 1230, 400); addDevice("PC17", "PC-PT", 1310, 400); addDevice("PC18", "PC-PT", 1390, 400);
addDevice("PC19", "PC-PT", 1480, 400); addDevice("PC20", "PC-PT", 1560, 400); addDevice("PC21", "PC-PT", 1640, 400);
addDevice("PC22", "PC-PT", 1730, 400); addDevice("PC23", "PC-PT", 1810, 400); addDevice("PC24", "PC-PT", 1890, 400);
addDevice("PC25", "PC-PT", 1980, 400); addDevice("PC26", "PC-PT", 2060, 400); addDevice("PC27", "PC-PT", 2140, 400);
addDevice("PC28", "PC-PT", 2230, 400); addDevice("PC29", "PC-PT", 2310, 400); addDevice("PC30", "PC-PT", 2390, 400);
addDevice("PC31", "PC-PT", 2480, 400); addDevice("PC32", "PC-PT", 2560, 400); addDevice("PC33", "PC-PT", 2640, 400);
addDevice("PC34", "PC-PT", 2730, 400); addDevice("PC35", "PC-PT", 2810, 400); addDevice("PC36", "PC-PT", 2890, 400);
addDevice("PC37", "PC-PT", 2980, 400); addDevice("PC38", "PC-PT", 3060, 400); addDevice("PC39", "PC-PT", 3140, 400);
addDevice("PC40", "PC-PT", 3230, 400); addDevice("PC41", "PC-PT", 3310, 400); addDevice("PC42", "PC-PT", 3390, 400);
addDevice("PC43", "PC-PT", 3480, 400); addDevice("PC44", "PC-PT", 3560, 400); addDevice("PC45", "PC-PT", 3640, 400);

// ============================================================
// ENLACES ENTRE ROUTERS (cable cruzado — mismo tipo)
// ============================================================
addLink("R1",  "GigabitEthernet0/0", "R2",  "GigabitEthernet0/0", "cross");
addLink("R2",  "GigabitEthernet0/1", "R3",  "GigabitEthernet0/0", "cross");
addLink("R3",  "GigabitEthernet0/1", "R4",  "GigabitEthernet0/0", "cross");
addLink("R4",  "GigabitEthernet0/1", "R5",  "GigabitEthernet0/0", "cross");
addLink("R5",  "GigabitEthernet0/1", "R6",  "GigabitEthernet0/0", "cross");
addLink("R6",  "GigabitEthernet0/1", "R7",  "GigabitEthernet0/0", "cross");
addLink("R7",  "GigabitEthernet0/1", "R8",  "GigabitEthernet0/0", "cross");
addLink("R8",  "GigabitEthernet0/1", "R9",  "GigabitEthernet0/0", "cross");
addLink("R9",  "GigabitEthernet0/1", "R10", "GigabitEthernet0/0", "cross");
addLink("R10", "GigabitEthernet0/1", "R11", "GigabitEthernet0/0", "cross");
addLink("R11", "GigabitEthernet0/1", "R12", "GigabitEthernet0/0", "cross");
addLink("R12", "GigabitEthernet0/1", "R13", "GigabitEthernet0/0", "cross");
addLink("R13", "GigabitEthernet0/1", "R14", "GigabitEthernet0/0", "cross");
addLink("R14", "GigabitEthernet0/1", "R15", "GigabitEthernet0/0", "cross");

// ============================================================
// ENLACES ROUTERS -> SWITCHES (cable directo — diferente tipo)
// NOTA: R1 usa Gi0/1 para trunk RoaS (sin IP directa)
// ============================================================
addLink("R1",  "GigabitEthernet0/1", "SW1",  "GigabitEthernet0/1", "straight");
addLink("R2",  "GigabitEthernet0/2", "SW2",  "GigabitEthernet0/1", "straight");
addLink("R3",  "GigabitEthernet0/2", "SW3",  "GigabitEthernet0/1", "straight");
addLink("R4",  "GigabitEthernet0/2", "SW4",  "GigabitEthernet0/1", "straight");
addLink("R5",  "GigabitEthernet0/2", "SW5",  "GigabitEthernet0/1", "straight");
addLink("R6",  "GigabitEthernet0/2", "SW6",  "GigabitEthernet0/1", "straight");
addLink("R7",  "GigabitEthernet0/2", "SW7",  "GigabitEthernet0/1", "straight");
addLink("R8",  "GigabitEthernet0/2", "SW8",  "GigabitEthernet0/1", "straight");
addLink("R9",  "GigabitEthernet0/2", "SW9",  "GigabitEthernet0/1", "straight");
addLink("R10", "GigabitEthernet0/2", "SW10", "GigabitEthernet0/1", "straight");
addLink("R11", "GigabitEthernet0/2", "SW11", "GigabitEthernet0/1", "straight");
addLink("R12", "GigabitEthernet0/2", "SW12", "GigabitEthernet0/1", "straight");
addLink("R13", "GigabitEthernet0/2", "SW13", "GigabitEthernet0/1", "straight");
addLink("R14", "GigabitEthernet0/2", "SW14", "GigabitEthernet0/1", "straight");
addLink("R15", "GigabitEthernet0/1", "SW15", "GigabitEthernet0/1", "straight");

// ============================================================
// ENLACES SWITCHES -> PCS (cable directo)
// ============================================================
addLink("SW1",  "FastEthernet0/1", "PC1",  "FastEthernet0", "straight");
addLink("SW1",  "FastEthernet0/2", "PC2",  "FastEthernet0", "straight");
addLink("SW1",  "FastEthernet0/3", "PC3",  "FastEthernet0", "straight");
addLink("SW2",  "FastEthernet0/1", "PC4",  "FastEthernet0", "straight");
addLink("SW2",  "FastEthernet0/2", "PC5",  "FastEthernet0", "straight");
addLink("SW2",  "FastEthernet0/3", "PC6",  "FastEthernet0", "straight");
addLink("SW3",  "FastEthernet0/1", "PC7",  "FastEthernet0", "straight");
addLink("SW3",  "FastEthernet0/2", "PC8",  "FastEthernet0", "straight");
addLink("SW3",  "FastEthernet0/3", "PC9",  "FastEthernet0", "straight");
addLink("SW4",  "FastEthernet0/1", "PC10", "FastEthernet0", "straight");
addLink("SW4",  "FastEthernet0/2", "PC11", "FastEthernet0", "straight");
addLink("SW4",  "FastEthernet0/3", "PC12", "FastEthernet0", "straight");
addLink("SW5",  "FastEthernet0/1", "PC13", "FastEthernet0", "straight");
addLink("SW5",  "FastEthernet0/2", "PC14", "FastEthernet0", "straight");
addLink("SW5",  "FastEthernet0/3", "PC15", "FastEthernet0", "straight");
addLink("SW6",  "FastEthernet0/1", "PC16", "FastEthernet0", "straight");
addLink("SW6",  "FastEthernet0/2", "PC17", "FastEthernet0", "straight");
addLink("SW6",  "FastEthernet0/3", "PC18", "FastEthernet0", "straight");
addLink("SW7",  "FastEthernet0/1", "PC19", "FastEthernet0", "straight");
addLink("SW7",  "FastEthernet0/2", "PC20", "FastEthernet0", "straight");
addLink("SW7",  "FastEthernet0/3", "PC21", "FastEthernet0", "straight");
addLink("SW8",  "FastEthernet0/1", "PC22", "FastEthernet0", "straight");
addLink("SW8",  "FastEthernet0/2", "PC23", "FastEthernet0", "straight");
addLink("SW8",  "FastEthernet0/3", "PC24", "FastEthernet0", "straight");
addLink("SW9",  "FastEthernet0/1", "PC25", "FastEthernet0", "straight");
addLink("SW9",  "FastEthernet0/2", "PC26", "FastEthernet0", "straight");
addLink("SW9",  "FastEthernet0/3", "PC27", "FastEthernet0", "straight");
addLink("SW10", "FastEthernet0/1", "PC28", "FastEthernet0", "straight");
addLink("SW10", "FastEthernet0/2", "PC29", "FastEthernet0", "straight");
addLink("SW10", "FastEthernet0/3", "PC30", "FastEthernet0", "straight");
addLink("SW11", "FastEthernet0/1", "PC31", "FastEthernet0", "straight");
addLink("SW11", "FastEthernet0/2", "PC32", "FastEthernet0", "straight");
addLink("SW11", "FastEthernet0/3", "PC33", "FastEthernet0", "straight");
addLink("SW12", "FastEthernet0/1", "PC34", "FastEthernet0", "straight");
addLink("SW12", "FastEthernet0/2", "PC35", "FastEthernet0", "straight");
addLink("SW12", "FastEthernet0/3", "PC36", "FastEthernet0", "straight");
addLink("SW13", "FastEthernet0/1", "PC37", "FastEthernet0", "straight");
addLink("SW13", "FastEthernet0/2", "PC38", "FastEthernet0", "straight");
addLink("SW13", "FastEthernet0/3", "PC39", "FastEthernet0", "straight");
addLink("SW14", "FastEthernet0/1", "PC40", "FastEthernet0", "straight");
addLink("SW14", "FastEthernet0/2", "PC41", "FastEthernet0", "straight");
addLink("SW14", "FastEthernet0/3", "PC42", "FastEthernet0", "straight");
addLink("SW15", "FastEthernet0/1", "PC43", "FastEthernet0", "straight");
addLink("SW15", "FastEthernet0/2", "PC44", "FastEthernet0", "straight");
addLink("SW15", "FastEthernet0/3", "PC45", "FastEthernet0", "straight");

// ============================================================
// FIN DEL SCRIPT
// Siguiente paso: aplicar configs CLI desde la carpeta configs/
// Empieza por: configs/R01_router_on_stick.txt y configs/SW01_vlans_trunk.txt
// ============================================================
